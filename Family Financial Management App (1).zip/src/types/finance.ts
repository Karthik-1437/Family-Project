export interface Income {
  id: string;
  source: string;
  amount: number;
  date: string;
  recurring: boolean;
  frequency?: 'weekly' | 'monthly' | 'yearly';
}

export interface Expense {
  id: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  recurring: boolean;
  frequency?: 'weekly' | 'monthly' | 'yearly';
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string;
  category: 'emergency' | 'education' | 'vacation' | 'home' | 'other';
}

export interface BudgetCategory {
  category: string;
  allocated: number;
  spent: number;
  type: 'needs' | 'wants' | 'savings';
}

export const EXPENSE_CATEGORIES = [
  'Rent/Mortgage',
  'Groceries',
  'Utilities',
  'Transportation',
  'Healthcare',
  'Education',
  'Insurance',
  'Entertainment',
  'Dining Out',
  'Shopping',
  'Subscriptions',
  'Other'
] as const;

export const INCOME_SOURCES = [
  'Salary',
  'Freelance',
  'Business',
  'Investments',
  'Rental Income',
  'Other'
] as const;
