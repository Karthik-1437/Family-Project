import { useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
}

const STORAGE_KEY = 'family_finance_user';
const USERS_KEY = 'family_finance_users';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem(STORAGE_KEY);
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const register = (name: string, email: string, password: string): { success: boolean; error?: string } => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    
    // Check if user already exists
    if (users.find((u: any) => u.email === email)) {
      return { success: false, error: 'User with this email already exists' };
    }

    // Create new user
    const newUser: User = {
      id: crypto.randomUUID(),
      name,
      email,
    };

    // Store user credentials (in production, use proper backend authentication)
    users.push({ ...newUser, password });
    localStorage.setItem(USERS_KEY, JSON.stringify(users));

    // Set current user
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
    setUser(newUser);

    return { success: true };
  };

  const login = (email: string, password: string): { success: boolean; error?: string } => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
    const foundUser = users.find((u: any) => u.email === email && u.password === password);

    if (!foundUser) {
      return { success: false, error: 'Invalid email or password' };
    }

    const user: User = {
      id: foundUser.id,
      name: foundUser.name,
      email: foundUser.email,
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    setUser(user);

    return { success: true };
  };

  const logout = () => {
    localStorage.removeItem(STORAGE_KEY);
    setUser(null);
  };

  return {
    user,
    isLoading,
    register,
    login,
    logout,
  };
}
