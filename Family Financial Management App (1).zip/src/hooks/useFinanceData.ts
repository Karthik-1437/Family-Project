import { useState, useEffect } from 'react';
import { Income, Expense, SavingsGoal } from '../types/finance';

const STORAGE_KEYS = {
  INCOME: 'family_finance_income',
  EXPENSES: 'family_finance_expenses',
  SAVINGS: 'family_finance_savings',
};

export function useFinanceData() {
  const [incomes, setIncomes] = useState<Income[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const storedIncomes = localStorage.getItem(STORAGE_KEYS.INCOME);
    const storedExpenses = localStorage.getItem(STORAGE_KEYS.EXPENSES);
    const storedSavings = localStorage.getItem(STORAGE_KEYS.SAVINGS);

    if (storedIncomes) setIncomes(JSON.parse(storedIncomes));
    if (storedExpenses) setExpenses(JSON.parse(storedExpenses));
    if (storedSavings) setSavingsGoals(JSON.parse(storedSavings));
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INCOME, JSON.stringify(incomes));
  }, [incomes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVINGS, JSON.stringify(savingsGoals));
  }, [savingsGoals]);

  // Income functions
  const addIncome = (income: Omit<Income, 'id'>) => {
    const newIncome = { ...income, id: crypto.randomUUID() };
    setIncomes((prev) => [...prev, newIncome]);
  };

  const updateIncome = (id: string, updates: Partial<Income>) => {
    setIncomes((prev) =>
      prev.map((income) => (income.id === id ? { ...income, ...updates } : income))
    );
  };

  const deleteIncome = (id: string) => {
    setIncomes((prev) => prev.filter((income) => income.id !== id));
  };

  // Expense functions
  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense = { ...expense, id: crypto.randomUUID() };
    setExpenses((prev) => [...prev, newExpense]);
  };

  const updateExpense = (id: string, updates: Partial<Expense>) => {
    setExpenses((prev) =>
      prev.map((expense) => (expense.id === id ? { ...expense, ...updates } : expense))
    );
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((expense) => expense.id !== id));
  };

  // Savings functions
  const addSavingsGoal = (goal: Omit<SavingsGoal, 'id'>) => {
    const newGoal = { ...goal, id: crypto.randomUUID() };
    setSavingsGoals((prev) => [...prev, newGoal]);
  };

  const updateSavingsGoal = (id: string, updates: Partial<SavingsGoal>) => {
    setSavingsGoals((prev) =>
      prev.map((goal) => (goal.id === id ? { ...goal, ...updates } : goal))
    );
  };

  const deleteSavingsGoal = (id: string) => {
    setSavingsGoals((prev) => prev.filter((goal) => goal.id !== id));
  };

  return {
    incomes,
    expenses,
    savingsGoals,
    addIncome,
    updateIncome,
    deleteIncome,
    addExpense,
    updateExpense,
    deleteExpense,
    addSavingsGoal,
    updateSavingsGoal,
    deleteSavingsGoal,
  };
}
