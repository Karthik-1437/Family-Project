import { useState } from 'react';
import { useFinanceData } from '../hooks/useFinanceData';
import { formatCurrency, formatDate } from '../lib/financeUtils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Plus, Trash2, PiggyBank, TrendingUp, Target, GraduationCap, Home, Plane } from 'lucide-react';

const GOAL_CATEGORIES = [
  { value: 'emergency', label: 'Emergency Fund', icon: Target },
  { value: 'education', label: 'Education', icon: GraduationCap },
  { value: 'vacation', label: 'Vacation', icon: Plane },
  { value: 'home', label: 'Home Purchase', icon: Home },
  { value: 'other', label: 'Other', icon: PiggyBank },
] as const;

export function SavingsGoals() {
  const { savingsGoals, addSavingsGoal, updateSavingsGoal, deleteSavingsGoal } = useFinanceData();
  const [isOpen, setIsOpen] = useState(false);
  const [isContributeOpen, setIsContributeOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [contributeAmount, setContributeAmount] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    targetAmount: '',
    currentAmount: '',
    deadline: '',
    category: 'other' as 'emergency' | 'education' | 'vacation' | 'home' | 'other',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.targetAmount) return;

    addSavingsGoal({
      name: formData.name,
      targetAmount: parseFloat(formData.targetAmount),
      currentAmount: parseFloat(formData.currentAmount) || 0,
      deadline: formData.deadline,
      category: formData.category,
    });

    setFormData({
      name: '',
      targetAmount: '',
      currentAmount: '',
      deadline: '',
      category: 'other',
    });
    setIsOpen(false);
  };

  const handleContribute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGoal || !contributeAmount) return;

    const goal = savingsGoals.find((g) => g.id === selectedGoal);
    if (goal) {
      updateSavingsGoal(selectedGoal, {
        currentAmount: goal.currentAmount + parseFloat(contributeAmount),
      });
    }

    setContributeAmount('');
    setSelectedGoal(null);
    setIsContributeOpen(false);
  };

  const openContributeDialog = (goalId: string) => {
    setSelectedGoal(goalId);
    setIsContributeOpen(true);
  };

  const totalSaved = savingsGoals.reduce((sum, goal) => sum + goal.currentAmount, 0);
  const totalTarget = savingsGoals.reduce((sum, goal) => sum + goal.targetAmount, 0);
  const overallProgress = totalTarget > 0 ? (totalSaved / totalTarget) * 100 : 0;

  const getCategoryIcon = (category: string) => {
    const cat = GOAL_CATEGORIES.find((c) => c.value === category);
    return cat?.icon || PiggyBank;
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Total Saved</CardTitle>
            <CardDescription>Across all goals</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-green-600">{formatCurrency(totalSaved)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Total Target</CardTitle>
            <CardDescription>Combined goal amount</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-blue-600">{formatCurrency(totalTarget)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Overall Progress</CardTitle>
            <CardDescription>Across all savings goals</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-purple-600">{overallProgress.toFixed(1)}%</div>
            <Progress value={overallProgress} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Add Goal Button */}
      <div className="flex justify-end">
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="size-4 mr-2" />
              Add Savings Goal
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Savings Goal</DialogTitle>
              <DialogDescription>Set a new financial goal for your family</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Goal Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Emergency Fund, Family Vacation"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) =>
                    setFormData({ ...formData, category: value as any })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {GOAL_CATEGORIES.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="targetAmount">Target Amount ($)</Label>
                <Input
                  id="targetAmount"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={formData.targetAmount}
                  onChange={(e) => setFormData({ ...formData, targetAmount: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="currentAmount">Current Amount ($)</Label>
                <Input
                  id="currentAmount"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={formData.currentAmount}
                  onChange={(e) => setFormData({ ...formData, currentAmount: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deadline">Target Date</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                  required
                />
              </div>

              <DialogFooter>
                <Button type="submit">Create Goal</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Savings Goals List */}
      {savingsGoals.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12 text-muted-foreground">
            <PiggyBank className="size-12 mx-auto mb-4 opacity-20" />
            <p>No savings goals yet</p>
            <p>Click "Add Savings Goal" to get started</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {savingsGoals.map((goal) => {
            const progress = (goal.currentAmount / goal.targetAmount) * 100;
            const Icon = getCategoryIcon(goal.category);
            const daysUntilDeadline = Math.ceil(
              (new Date(goal.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
            );

            return (
              <Card key={goal.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg">
                        <Icon className="size-5 text-white" />
                      </div>
                      <div>
                        <CardTitle>{goal.name}</CardTitle>
                        <CardDescription className="capitalize">
                          {goal.category === 'other' ? 'Savings Goal' : goal.category}
                        </CardDescription>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteSavingsGoal(goal.id)}
                    >
                      <Trash2 className="size-4 text-red-600" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Progress</span>
                      <span>
                        {formatCurrency(goal.currentAmount)} / {formatCurrency(goal.targetAmount)}
                      </span>
                    </div>
                    <Progress value={Math.min(progress, 100)} />
                    <p className="text-muted-foreground">
                      {progress.toFixed(1)}% complete
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t">
                    <div>
                      <p className="text-muted-foreground">Target Date</p>
                      <p>{formatDate(goal.deadline)}</p>
                      <p className="text-muted-foreground">
                        {daysUntilDeadline > 0 ? `${daysUntilDeadline} days left` : 'Deadline passed'}
                      </p>
                    </div>
                    <Button onClick={() => openContributeDialog(goal.id)}>
                      <TrendingUp className="size-4 mr-2" />
                      Contribute
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Contribute Dialog */}
      <Dialog open={isContributeOpen} onOpenChange={setIsContributeOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Contribute to Savings Goal</DialogTitle>
            <DialogDescription>Add money to your savings goal</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleContribute} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="contributeAmount">Amount to Add ($)</Label>
              <Input
                id="contributeAmount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={contributeAmount}
                onChange={(e) => setContributeAmount(e.target.value)}
                required
              />
            </div>
            <DialogFooter>
              <Button type="submit">Add to Savings</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
