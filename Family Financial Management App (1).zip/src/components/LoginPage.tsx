import { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Wallet, Mail, Lock, AlertCircle } from 'lucide-react';
import brandImage from 'figma:asset/5f66298d236ac843ce9eed89dd92250ac3c8597a.png';

interface LoginPageProps {
  onLogin: (email: string, password: string) => { success: boolean; error?: string };
  onSwitchToRegister: () => void;
}

export function LoginPage({ onLogin, onSwitchToRegister }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const result = onLogin(email, password);
    
    if (!result.success) {
      setError(result.error || 'Login failed');
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-purple-300 to-purple-200 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid md:grid-cols-2 gap-8 items-center">
        {/* Left Side - Branding */}
        <div className="hidden md:block">
          <img 
            src={brandImage} 
            alt="Financial Management for Families" 
            className="w-full h-auto rounded-2xl shadow-2xl"
          />
        </div>

        {/* Right Side - Login Form */}
        <div className="w-full">
          {/* Logo/Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center p-3 bg-white rounded-2xl mb-4 shadow-lg">
              <Wallet className="size-12 text-purple-600" />
            </div>
            <h1 className="text-white mb-2">Welcome Back!</h1>
            <p className="text-purple-100">Login to manage your family finances</p>
          </div>

          {/* Login Card */}
          <Card className="shadow-2xl">
            <CardHeader>
              <CardTitle>Login to Your Account</CardTitle>
              <CardDescription>Enter your credentials to access your dashboard</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="size-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 size-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 size-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700" disabled={isLoading}>
                  {isLoading ? 'Logging in...' : 'Login'}
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <div className="text-center w-full">
                <p className="text-muted-foreground">
                  Don't have an account?{' '}
                  <Button
                    variant="link"
                    className="p-0 text-purple-600"
                    onClick={onSwitchToRegister}
                  >
                    Register here
                  </Button>
                </p>
              </div>
            </CardFooter>
          </Card>

          {/* Info Card */}
          <Card className="mt-4 border-white bg-white/90 backdrop-blur-sm">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-purple-900">
                  <strong>Manage Your Household Finances</strong>
                </p>
                <p className="text-purple-700 mt-2">
                  Budget Planning • Expense Tracking • Savings Goals
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}