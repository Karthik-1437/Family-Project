import { useFinanceData } from '../hooks/useFinanceData';
import { calculateMonthlyIncome, calculateMonthlyExpenses, calculateExpensesByCategory, formatCurrency, calculateBudgetAllocation, getCategoryType } from '../lib/financeUtils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { DollarSign, TrendingDown, TrendingUp, AlertTriangle, PiggyBank, Wallet } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

export function Dashboard() {
  const { incomes, expenses, savingsGoals } = useFinanceData();
  
  const currentMonth = new Date().toISOString().slice(0, 7);
  const monthlyIncome = calculateMonthlyIncome(incomes, currentMonth);
  const monthlyExpenses = calculateMonthlyExpenses(expenses, currentMonth);
  const balance = monthlyIncome - monthlyExpenses;
  const expensesByCategory = calculateExpensesByCategory(expenses, currentMonth);
  const budgetAllocation = calculateBudgetAllocation(monthlyIncome);
  
  // Calculate spending by type
  const spendingByType = Object.entries(expensesByCategory).reduce(
    (acc, [category, amount]) => {
      const type = getCategoryType(category);
      acc[type] = (acc[type] || 0) + amount;
      return acc;
    },
    { needs: 0, wants: 0, savings: 0 } as Record<string, number>
  );

  // Check for overspending alerts
  const alerts = [];
  if (spendingByType.needs > budgetAllocation.needs) {
    alerts.push({
      type: 'needs',
      over: spendingByType.needs - budgetAllocation.needs,
    });
  }
  if (spendingByType.wants > budgetAllocation.wants) {
    alerts.push({
      type: 'wants',
      over: spendingByType.wants - budgetAllocation.wants,
    });
  }

  // Emergency fund calculation
  const emergencyGoal = savingsGoals.find((g) => g.category === 'emergency');
  const monthlyExpensesAvg = monthlyExpenses || 2000;
  const emergencyFundTarget = monthlyExpensesAvg * 6;
  const emergencyFundCurrent = emergencyGoal?.currentAmount || 0;
  const emergencyFundProgress = (emergencyFundCurrent / emergencyFundTarget) * 100;

  // Total savings
  const totalSavings = savingsGoals.reduce((sum, goal) => sum + goal.currentAmount, 0);

  return (
    <div className="space-y-6">
      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-3">
          {alerts.map((alert, index) => (
            <Alert key={index} variant="destructive">
              <AlertTriangle className="size-4" />
              <AlertTitle>Overspending Alert!</AlertTitle>
              <AlertDescription>
                You've exceeded your {alert.type} budget by {formatCurrency(alert.over)} this month.
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Monthly Income</CardTitle>
            <DollarSign className="size-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-green-600">{formatCurrency(monthlyIncome)}</div>
            <p className="text-muted-foreground">Total income this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Monthly Expenses</CardTitle>
            <TrendingDown className="size-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-red-600">{formatCurrency(monthlyExpenses)}</div>
            <p className="text-muted-foreground">Total expenses this month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Balance</CardTitle>
            <Wallet className="size-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className={balance >= 0 ? 'text-green-600' : 'text-red-600'}>
              {formatCurrency(balance)}
            </div>
            <p className="text-muted-foreground">Income - Expenses</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle>Total Savings</CardTitle>
            <PiggyBank className="size-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-purple-600">{formatCurrency(totalSavings)}</div>
            <p className="text-muted-foreground">Across all goals</p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Allocation - 50/30/20 Rule */}
      <Card>
        <CardHeader>
          <CardTitle>Budget Allocation (50/30/20 Rule)</CardTitle>
          <CardDescription>
            50% Needs • 30% Wants • 20% Savings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Needs (50%)</span>
              <span>
                {formatCurrency(spendingByType.needs)} / {formatCurrency(budgetAllocation.needs)}
              </span>
            </div>
            <Progress 
              value={(spendingByType.needs / budgetAllocation.needs) * 100} 
              className={spendingByType.needs > budgetAllocation.needs ? 'bg-red-200' : ''}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Wants (30%)</span>
              <span>
                {formatCurrency(spendingByType.wants)} / {formatCurrency(budgetAllocation.wants)}
              </span>
            </div>
            <Progress 
              value={(spendingByType.wants / budgetAllocation.wants) * 100}
              className={spendingByType.wants > budgetAllocation.wants ? 'bg-red-200' : ''}
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Savings (20%)</span>
              <span>
                {formatCurrency(spendingByType.savings)} / {formatCurrency(budgetAllocation.savings)}
              </span>
            </div>
            <Progress value={(spendingByType.savings / budgetAllocation.savings) * 100} />
          </div>
        </CardContent>
      </Card>

      {/* Emergency Fund */}
      <Card>
        <CardHeader>
          <CardTitle>Emergency Fund</CardTitle>
          <CardDescription>
            Target: 6 months of expenses ({formatCurrency(emergencyFundTarget)})
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Progress</span>
              <span>{formatCurrency(emergencyFundCurrent)} saved</span>
            </div>
            <Progress value={emergencyFundProgress} />
            <p className="text-muted-foreground">
              {emergencyFundProgress.toFixed(1)}% of goal achieved
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Savings Goals Summary */}
      {savingsGoals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Savings Goals Progress</CardTitle>
            <CardDescription>Track your family's savings objectives</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {savingsGoals.slice(0, 3).map((goal) => {
              const progress = (goal.currentAmount / goal.targetAmount) * 100;
              return (
                <div key={goal.id} className="space-y-2">
                  <div className="flex justify-between">
                    <span>{goal.name}</span>
                    <span>
                      {formatCurrency(goal.currentAmount)} / {formatCurrency(goal.targetAmount)}
                    </span>
                  </div>
                  <Progress value={progress} />
                </div>
              );
            })}
            {savingsGoals.length > 3 && (
              <p className="text-muted-foreground">
                +{savingsGoals.length - 3} more goals
              </p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
