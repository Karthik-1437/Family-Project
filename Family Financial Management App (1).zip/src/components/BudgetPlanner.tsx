import { useFinanceData } from '../hooks/useFinanceData';
import { calculateMonthlyIncome, calculateExpensesByCategory, calculateBudgetAllocation, formatCurrency, getCategoryType } from '../lib/financeUtils';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { AlertCircle, CheckCircle2, TrendingUp } from 'lucide-react';

export function BudgetPlanner() {
  const { incomes, expenses } = useFinanceData();
  
  const currentMonth = new Date().toISOString().slice(0, 7);
  const monthlyIncome = calculateMonthlyIncome(incomes, currentMonth);
  const expensesByCategory = calculateExpensesByCategory(expenses, currentMonth);
  const budgetAllocation = calculateBudgetAllocation(monthlyIncome);

  // Calculate actual spending by type
  const spendingByType = Object.entries(expensesByCategory).reduce(
    (acc, [category, amount]) => {
      const type = getCategoryType(category);
      acc[type] = (acc[type] || 0) + amount;
      return acc;
    },
    { needs: 0, wants: 0, savings: 0 } as Record<string, number>
  );

  // Prepare data for pie chart
  const pieData = [
    { name: 'Needs (50%)', value: budgetAllocation.needs, color: '#3b82f6' },
    { name: 'Wants (30%)', value: budgetAllocation.wants, color: '#8b5cf6' },
    { name: 'Savings (20%)', value: budgetAllocation.savings, color: '#10b981' },
  ];

  const actualSpendingData = [
    { name: 'Needs', value: spendingByType.needs, color: '#3b82f6' },
    { name: 'Wants', value: spendingByType.wants, color: '#8b5cf6' },
    { name: 'Savings', value: spendingByType.savings, color: '#10b981' },
  ].filter(item => item.value > 0);

  // Category breakdown
  const categoryBreakdown = Object.entries(expensesByCategory).map(([category, amount]) => {
    const type = getCategoryType(category);
    const allocated = budgetAllocation[type];
    const typeSpent = spendingByType[type];
    const categoryPercentage = (amount / typeSpent) * 100;
    
    return {
      category,
      amount,
      type,
      isOverBudget: typeSpent > allocated,
      percentage: categoryPercentage,
    };
  }).sort((a, b) => b.amount - a.amount);

  return (
    <div className="space-y-6">
      {/* Income Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Income</CardTitle>
          <CardDescription>Your total income for budget planning</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-green-600">{formatCurrency(monthlyIncome)}</div>
          {monthlyIncome === 0 && (
            <p className="text-muted-foreground mt-2">
              Add income sources to see your budget allocation
            </p>
          )}
        </CardContent>
      </Card>

      {/* 50/30/20 Rule Visualization */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Recommended Budget */}
        <Card>
          <CardHeader>
            <CardTitle>Recommended Budget (50/30/20)</CardTitle>
            <CardDescription>Ideal allocation based on your income</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${formatCurrency(value)}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => formatCurrency(value)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Actual Spending */}
        <Card>
          <CardHeader>
            <CardTitle>Actual Spending</CardTitle>
            <CardDescription>Your current month's spending distribution</CardDescription>
          </CardHeader>
          <CardContent>
            {actualSpendingData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={actualSpendingData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${formatCurrency(value)}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {actualSpendingData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => formatCurrency(value)} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No expenses recorded yet
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Budget Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Budget Progress by Category</CardTitle>
          <CardDescription>Track spending against the 50/30/20 rule</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Needs */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                <span>Needs (50%)</span>
                {spendingByType.needs <= budgetAllocation.needs ? (
                  <CheckCircle2 className="size-4 text-green-600" />
                ) : (
                  <AlertCircle className="size-4 text-red-600" />
                )}
              </div>
              <span>
                {formatCurrency(spendingByType.needs)} / {formatCurrency(budgetAllocation.needs)}
              </span>
            </div>
            <Progress 
              value={Math.min((spendingByType.needs / budgetAllocation.needs) * 100, 100)}
              className={spendingByType.needs > budgetAllocation.needs ? '[&>div]:bg-red-600' : '[&>div]:bg-blue-600'}
            />
            {spendingByType.needs > budgetAllocation.needs && (
              <p className="text-red-600">
                Over budget by {formatCurrency(spendingByType.needs - budgetAllocation.needs)}
              </p>
            )}
          </div>

          {/* Wants */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                <span>Wants (30%)</span>
                {spendingByType.wants <= budgetAllocation.wants ? (
                  <CheckCircle2 className="size-4 text-green-600" />
                ) : (
                  <AlertCircle className="size-4 text-red-600" />
                )}
              </div>
              <span>
                {formatCurrency(spendingByType.wants)} / {formatCurrency(budgetAllocation.wants)}
              </span>
            </div>
            <Progress 
              value={Math.min((spendingByType.wants / budgetAllocation.wants) * 100, 100)}
              className={spendingByType.wants > budgetAllocation.wants ? '[&>div]:bg-red-600' : '[&>div]:bg-purple-600'}
            />
            {spendingByType.wants > budgetAllocation.wants && (
              <p className="text-red-600">
                Over budget by {formatCurrency(spendingByType.wants - budgetAllocation.wants)}
              </p>
            )}
          </div>

          {/* Savings */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span>Savings (20%)</span>
                {spendingByType.savings >= budgetAllocation.savings ? (
                  <CheckCircle2 className="size-4 text-green-600" />
                ) : (
                  <TrendingUp className="size-4 text-yellow-600" />
                )}
              </div>
              <span>
                {formatCurrency(spendingByType.savings)} / {formatCurrency(budgetAllocation.savings)}
              </span>
            </div>
            <Progress 
              value={Math.min((spendingByType.savings / budgetAllocation.savings) * 100, 100)}
              className="[&>div]:bg-green-600"
            />
            {spendingByType.savings < budgetAllocation.savings && (
              <p className="text-yellow-600">
                {formatCurrency(budgetAllocation.savings - spendingByType.savings)} more needed to reach goal
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Detailed Category Breakdown */}
      {categoryBreakdown.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Expense Breakdown by Category</CardTitle>
            <CardDescription>Detailed view of spending categories</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {categoryBreakdown.map((item) => (
                <div key={item.category} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>{item.category}</span>
                      <span className="text-muted-foreground">
                        ({item.type})
                      </span>
                    </div>
                    <span className={item.isOverBudget ? 'text-red-600' : ''}>
                      {formatCurrency(item.amount)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress 
                      value={item.percentage} 
                      className="flex-1"
                    />
                    <span className="text-muted-foreground w-12 text-right">
                      {item.percentage.toFixed(0)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
