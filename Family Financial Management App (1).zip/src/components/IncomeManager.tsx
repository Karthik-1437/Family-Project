import { useState } from 'react';
import { useFinanceData } from '../hooks/useFinanceData';
import { formatCurrency, formatDate } from '../lib/financeUtils';
import { INCOME_SOURCES } from '../types/finance';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { Plus, Trash2, Edit, DollarSign } from 'lucide-react';

export function IncomeManager() {
  const { incomes, addIncome, deleteIncome } = useFinanceData();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    source: '',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    recurring: false,
    frequency: 'monthly' as 'weekly' | 'monthly' | 'yearly',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.source || !formData.amount) return;

    addIncome({
      source: formData.source,
      amount: parseFloat(formData.amount),
      date: formData.date,
      recurring: formData.recurring,
      frequency: formData.recurring ? formData.frequency : undefined,
    });

    setFormData({
      source: '',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      recurring: false,
      frequency: 'monthly',
    });
    setIsOpen(false);
  };

  const totalIncome = incomes.reduce((sum, income) => sum + income.amount, 0);
  const currentMonthIncome = incomes
    .filter((income) => income.date.startsWith(new Date().toISOString().slice(0, 7)))
    .reduce((sum, income) => sum + income.amount, 0);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>This Month's Income</CardTitle>
            <CardDescription>Total income for current month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-green-600">{formatCurrency(currentMonthIncome)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Total Income (All Time)</CardTitle>
            <CardDescription>Sum of all recorded income</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-green-600">{formatCurrency(totalIncome)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Income Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Income Sources</CardTitle>
              <CardDescription>Manage your household income streams</CardDescription>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="size-4 mr-2" />
                  Add Income
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Income Source</DialogTitle>
                  <DialogDescription>Record a new source of income</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="source">Income Source</Label>
                    <Select
                      value={formData.source}
                      onValueChange={(value) => setFormData({ ...formData, source: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select source" />
                      </SelectTrigger>
                      <SelectContent>
                        {INCOME_SOURCES.map((source) => (
                          <SelectItem key={source} value={source}>
                            {source}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount ($)</Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      min="0"
                      placeholder="0.00"
                      value={formData.amount}
                      onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      required
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="recurring"
                      checked={formData.recurring}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, recurring: checked as boolean })
                      }
                    />
                    <Label htmlFor="recurring">Recurring Income</Label>
                  </div>

                  {formData.recurring && (
                    <div className="space-y-2">
                      <Label htmlFor="frequency">Frequency</Label>
                      <Select
                        value={formData.frequency}
                        onValueChange={(value) =>
                          setFormData({ ...formData, frequency: value as any })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="yearly">Yearly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <DialogFooter>
                    <Button type="submit">Add Income</Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {incomes.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <DollarSign className="size-12 mx-auto mb-4 opacity-20" />
              <p>No income recorded yet</p>
              <p>Click "Add Income" to get started</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Source</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Frequency</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {incomes
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((income) => (
                    <TableRow key={income.id}>
                      <TableCell>{income.source}</TableCell>
                      <TableCell className="text-green-600">
                        {formatCurrency(income.amount)}
                      </TableCell>
                      <TableCell>{formatDate(income.date)}</TableCell>
                      <TableCell>
                        {income.recurring ? (
                          <span className="text-blue-600 capitalize">{income.frequency}</span>
                        ) : (
                          <span className="text-gray-400">One-time</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteIncome(income.id)}
                        >
                          <Trash2 className="size-4 text-red-600" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
