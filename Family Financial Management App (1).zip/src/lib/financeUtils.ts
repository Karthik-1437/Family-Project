import { Income, Expense } from '../types/finance';

export function calculateMonthlyIncome(incomes: Income[], month?: string): number {
  const targetMonth = month || new Date().toISOString().slice(0, 7);
  
  return incomes
    .filter((income) => income.date.startsWith(targetMonth))
    .reduce((sum, income) => sum + income.amount, 0);
}

export function calculateMonthlyExpenses(expenses: Expense[], month?: string): number {
  const targetMonth = month || new Date().toISOString().slice(0, 7);
  
  return expenses
    .filter((expense) => expense.date.startsWith(targetMonth))
    .reduce((sum, expense) => sum + expense.amount, 0);
}

export function calculateExpensesByCategory(
  expenses: Expense[],
  month?: string
): Record<string, number> {
  const targetMonth = month || new Date().toISOString().slice(0, 7);
  
  const filtered = expenses.filter((expense) => expense.date.startsWith(targetMonth));
  
  return filtered.reduce((acc, expense) => {
    acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
    return acc;
  }, {} as Record<string, number>);
}

export function calculateBudgetAllocation(
  totalIncome: number
): { needs: number; wants: number; savings: number } {
  return {
    needs: totalIncome * 0.5,
    wants: totalIncome * 0.3,
    savings: totalIncome * 0.2,
  };
}

export function getCategoryType(category: string): 'needs' | 'wants' | 'savings' {
  const needs = [
    'Rent/Mortgage',
    'Groceries',
    'Utilities',
    'Transportation',
    'Healthcare',
    'Insurance',
  ];
  
  const savings = ['Savings', 'Investment', 'Emergency Fund'];
  
  if (needs.includes(category)) return 'needs';
  if (savings.includes(category)) return 'savings';
  return 'wants';
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function getMonthName(monthString: string): string {
  const date = new Date(monthString + '-01');
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

export function getLast6Months(): string[] {
  const months: string[] = [];
  const now = new Date();
  
  for (let i = 5; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push(date.toISOString().slice(0, 7));
  }
  
  return months;
}
